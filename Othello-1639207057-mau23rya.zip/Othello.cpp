#include <bits/stdc++.h>
using namespace std;

class Othello
{
    vector<vector<char>> board;
    int n = 8;
    int player;
    int winner;
    unordered_map<char, int> remainingCoins;
    unordered_map<char, int> coinsCountOnBoard;

public:
    Othello()
    {
        player = 1;
        winner = 0;
        vector<char> temp;
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                temp.push_back('-');
            }
            board.push_back(temp);
        }
        board[3][3] = 'B';
        board[3][4] = 'W';
        board[4][3] = 'W';
        board[4][4] = 'B';
        remainingCoins.insert({'B', 30});
        remainingCoins.insert({'W', 30});
        coinsCountOnBoard.insert({'B', 2});
        coinsCountOnBoard.insert({'W', 2});
    }

private:
    bool checkFlip(char colour, int row, int col, int deltaRow, int deltaCol)
    {
        char oppColour = 'W';
        if (colour == 'W')
        {
            oppColour = 'B';
        }

        if ((row < 0) || (row >= 8) || (col < 0) || (col >= 8))
        {
            return false;
        }

        if (board[row][col] == oppColour)
        {
            while ((row >= 0) && (row < 8) && (col >= 0) && (col < 8))
            {
                row += deltaRow;
                col += deltaCol;
                if (board[row][col] == '-')
                {
                    return false;
                }
                if (board[row][col] == colour)
                {
                    return true;
                }
            }
        }
        return false;
    }
    void changeCoins(char colour, int row, int col, int deltaRow, int deltaCol)
    {
        char oppColour = 'W';
        if (colour == 'W')
        {
            oppColour = 'B';
        }

        while (board[row][col] == oppColour)
        {
            board[row][col] = colour;
            coinsCountOnBoard[colour]++;
            coinsCountOnBoard[oppColour]--;
            row += deltaRow;
            col += deltaCol;
        }
        return;
    }

public:
    bool isValidMove(int row, int col)
    {
        if ((row < 0) || (row >= 8) || (col < 0) || (col >= 8))
        {
            return false;
        }

        if (board[row][col] != '-')
        {
            return false;
        }

        char colour = 'W';
        if (getPlayer() == 1)
        {
            colour = 'B';
        }

        // Check Up
        if (checkFlip(colour, row - 1, col, -1, 0))
        {
            return true;
        }
        // Check Down
        if (checkFlip(colour, row + 1, col, 1, 0))
        {
            return true;
        }
        // Check Left
        if (checkFlip(colour, row, col - 1, 0, -1))
        {
            return true;
        }
        // Check Right
        if (checkFlip(colour, row, col + 1, 0, 1))
        {
            return true;
        }
        // Check Down-Right
        if (checkFlip(colour, row + 1, col + 1, 1, 1))
        {
            return true;
        }
        // Check Down-Left
        if (checkFlip(colour, row + 1, col - 1, 1, -1))
        {
            return true;
        }
        // Check Top-Right
        if (checkFlip(colour, row - 1, col + 1, -1, 1))
        {
            return true;
        }
        // Check Top-Left
        if (checkFlip(colour, row - 1, col - 1, -1, -1))
        {
            return true;
        }

        return false;
    }
    void makeMove(int row, int col)
    {
        char colour = 'W';
        if (getPlayer() == 1)
        {
            colour = 'B';
        }
        board[row][col] = colour;
        remainingCoins[colour]--;
        coinsCountOnBoard[colour]++;

        // Check Up
        if (checkFlip(colour, row - 1, col, -1, 0))
        {
            changeCoins(colour, row - 1, col, -1, 0);
        }
        // Check Down
        if (checkFlip(colour, row + 1, col, 1, 0))
        {
            changeCoins(colour, row + 1, col, 1, 0);
        }
        // Check Left
        if (checkFlip(colour, row, col - 1, 0, -1))
        {
            changeCoins(colour, row, col - 1, 0, -1);
        }
        // Check Right
        if (checkFlip(colour, row, col + 1, 0, 1))
        {
            changeCoins(colour, row, col + 1, 0, 1);
        }
        // Check Down-Right
        if (checkFlip(colour, row + 1, col + 1, 1, 1))
        {
            changeCoins(colour, row + 1, col + 1, 1, 1);
        }
        // Check Down-Left
        if (checkFlip(colour, row + 1, col - 1, 1, -1))
        {
            changeCoins(colour, row + 1, col - 1, 1, -1);
        }
        // Check Top-Right
        if (checkFlip(colour, row - 1, col + 1, -1, 1))
        {
            changeCoins(colour, row - 1, col + 1, -1, 1);
        }
        // Check Top-Left
        if (checkFlip(colour, row - 1, col - 1, -1, -1))
        {
            changeCoins(colour, row - 1, col - 1, -1, -1);
        }
        player = -1 * player;
        return;
    }
    void displayBoard()
    {
        for (int i = 0; i < n; i++)
        {
            cout << i << "\t";
            for (int j = 0; j < n; j++)
            {
                cout << board[i][j] << "\t";
            }
            cout << "\n";
        }
        cout << "\t0\t1\t2\t3\t4\t5\t6\t7\n";
        cout << "Coins left for Player-" << getPlayer() << ": " << remainingCoins['B'] << "\n";
        cout << "Coins left for Player-" << getOppPlayer() << ": " << remainingCoins['W'] << "\n";
        cout << "Coins on board for Player-" << getPlayer() << ": " << coinsCountOnBoard['B'] << "\n";
        cout << "Coins on board for Player-" << getOppPlayer() << ": " << coinsCountOnBoard['W'] << "\n";
        return;
    }
    bool isGameOver()
    {
        if (coinsCountOnBoard['B'] == 0)
        {
            winner = -1;
            return true;
        }
        else if (coinsCountOnBoard['W'] == 0)
        {
            winner = 1;
            return true;
        }
        else if (remainingCoins['B'] == 0 && remainingCoins['W'] == 0)
        {
            if (coinsCountOnBoard['B'] > coinsCountOnBoard['W'])
            {
                winner = 1;
            }
            else if (coinsCountOnBoard['B'] < coinsCountOnBoard['W'])
            {
                winner = -1;
            }
            else
            {
                winner = 0;
            }
            return true;
        }
        return false;
    }
    int getPlayer()
    {
        if (player == -1)
        {
            return 2;
        }
        return player;
    }
    int getOppPlayer()
    {
        if (player == -1)
        {
            return 1;
        }
        return 2;
    }
    int getWinner()
    {
        return winner;
    }
};

int main()
{
    Othello Game;
    cout << "The Game has started.\n";
    Game.displayBoard();
    int row;
    int col;

    while (!Game.isGameOver())
    {
        cout << "Player-" << Game.getPlayer() << "'s turn.\n";
        cout << "Enter the Row Number: ";
        cin >> row;
        cout << "Enter the Column Number: ";
        cin >> col;

        if (Game.isValidMove(row, col))
        {
            Game.makeMove(row, col);
        }
        else
        {
            cout << "Invalid Move. Try Again.\n";
        }

        Game.displayBoard();
    }

    cout << "Game Over.\n";
    if (Game.getWinner() != 0)
    {
        cout << "The winner is Player-" << Game.getWinner() << ".\n";
    }
    else
    {
        cout << "The match ended in a draw.\n";
    }

    return 0;
}